
.\python_embeded\python.exe -s ComfyUI\main.py --windows-standalone-build --fast fp16_accumulation --lowvram --cache-none --reserve-vram 4
pause

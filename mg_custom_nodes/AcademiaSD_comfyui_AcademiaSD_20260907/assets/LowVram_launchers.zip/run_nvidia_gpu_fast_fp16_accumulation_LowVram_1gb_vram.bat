
.\python_embeded\python.exe -s ComfyUI\main.py --windows-standalone-build --fast fp16_accumulation --novram --cache-none --reserve-vram 1
pause
